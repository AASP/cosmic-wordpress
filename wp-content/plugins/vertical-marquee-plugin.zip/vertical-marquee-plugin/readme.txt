=== Vertical marquee plugin ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/
Author URI: http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/
Plugin URI: http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/
Tags: vertical, marquee, plugin
Requires at least: 3.4
Tested up to: 4.0
Stable tag: 5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
You can use this vertical marquee plugin to make your text scroll upward or downwards.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)

*   [Live Demo](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)	
*   [More info](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)				
*   [Comments/Suggestion](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)		

I have created this simple plugin because of the users request, You can use this vertical marquee plugin to make your text scroll upward or downwards. This plugin will work all leading browsers except old Netscape browsers. In this plugin i used simple HTML marquee tag to scroll the plugin and it loads very fast, and it is pure HTML so no java script required. admin option available to change the text style and marquee speed.

**Features of this plugin**

*   Light weight
*   Loads very fast
*   Pure HTML tags

**Plugin configuration**

*   Drag and drop the widget
*   Short code for pages and posts 
*   Add directly in the theme

http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/	

== Installation ==

**Installation Instruction & Configuration**  

[Installation Instruction](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)								
[Configuration](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)											
[Live demo](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)									

== Frequently Asked Questions ==

Q1. What is Scroll Amount, Scroll Delay?

Q2. Can you explain the short code?

[Answer page](http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/)

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/

1. Admin Screen. http://www.gopiplus.com/work/2012/06/30/vertical-marquee-wordpress-plugin/

== Changelog ==

= 1.0 =	

First version

= 2.0 =	

New demo link

= 3.0 =	

New option to add expiration date for the message

= 4.0 =	

Tested upto 3.4.2

= 4.1 =	

Tested upto 3.5
New PHP code to add plugin directly in the theme file.

= 5.0 =

Tested up to 3.6
New admin interface.
Added few security features.

= 5.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (vertical-marquee.po) available in the languages folder.

= 5.2 =

1. Tested up to 3.9
2. Small security update.

= 5.3 =

From this version onwards plugin support multi widget. If your using widget option and upgrading the plugin, This upgrade will remove the widget from your sidebar. Thus please go to your dashboard widget menu and drag and drop the widget again (One time work, not required in future)

= 5.4 =

1. Tested up to 4.0

== Upgrade Notice ==

= 1.0 =				

First version.

= 2.0 =	

New demo link

= 3.0 =	

New option to add expiration date for the message

= 4.0 =	

Tested upto 3.4.2

= 4.1 =	

Tested upto 3.5
New PHP code to add plugin directly in the theme file.

= 5.0 =

Tested up to 3.6
New admin interface.
Added few security features.

= 5.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (vertical-marquee.po) available in the languages folder.

= 5.2 =

1. Tested up to 3.9
2. Small security update.

= 5.3 =

From this version onwards plugin support multi widget. If your using widget option and upgrading the plugin, This upgrade will remove the widget from your sidebar. Thus please go to your dashboard widget menu and drag and drop the widget again (One time work, not required in future)

= 5.4 =

1. Tested up to 4.0