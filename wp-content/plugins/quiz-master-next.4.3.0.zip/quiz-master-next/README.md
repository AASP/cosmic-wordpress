Quiz Master Next For WordPress
================

The easiest and most flexible way to add multiple quizzes, tests, and surveys to your website.

Feel free to browse the code and make suggestions/requests. Thanks!
