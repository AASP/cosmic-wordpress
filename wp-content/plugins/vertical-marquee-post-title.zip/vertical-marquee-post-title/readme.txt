=== Vertical marquee post title ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/
Author URI: http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/
Plugin URI: http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/
Tags: vertical, marquee, plugin
Requires at least: 3.4
Tested up to: 4.0
Stable tag: 2.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
If you want your post title to move vertically (scroll upward or downwards) in the screen use this plug-in.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)

*   [Live Demo](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)	
*   [More info](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)				
*   [Comments/Suggestion](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)		

This plug-in will create the vertical marquee effect in your website, if you want your post title to move vertically (scroll upward or downwards) in the screen use this plug-in. We are using the simple marquee tag to move the text vertically, and tested this plug-in in all the leading internet browsers. admin option available to set the scroll effects and colors scheme.

Short code available,	

http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/

See the live demo!	

[Demo](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)		
[To see my more plugin](http://www.gopiplus.com/work/plugin-list/)		

== Installation ==

**Installation Instruction & Configuration**  

[Installation Instruction](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)								
[Configuration](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)											
[Live demo](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)									

== Frequently Asked Questions ==

Q1. What is Scroll Amount, Scroll Delay?

Q2. Can you explain the short code?

[Answer page](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)			
[Contact](http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/)	

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/

2. Admin Screen. http://www.gopiplus.com/work/2012/09/02/vertical-marquee-post-title-wordpress-plugin/

== Changelog ==

= 1.0 =	

First version

= 1.1 =	

Tested up to 3.5

= 2.0 =	

Tested up to 3.6
Added some security feature.

= 2.1 =	

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (vertical-marquee-post-title.po) available in the languages folder.

= 2.2 =	

1. Tested up to 3.9
2. Small bug fixed in the link
3. Now plugin supports multi widget option.

= 2.3 =	

1. Tested up to 4.0

== Upgrade Notice ==

= 1.0 =				

First version

= 1.1 =	

Tested up to 3.5

= 2.0 =	

Tested up to 3.6
Added some security feature.

= 2.1 =	

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (vertical-marquee-post-title.po) available in the languages folder.

= 2.2 =	

1. Tested up to 3.9
2. Small bug fixed in the link
3. Now plugin supports multi widget option.

= 2.3 =	

1. Tested up to 4.0