<!-- /** WP standard admin block ( div postbox / h3 hndle / div inside / p ) **/ -->
<div class="postbox" id="control">
<h3 id="main_settings" class="hndle">Main settings</h3>
<div class="inside">

<p>Hello, World!</p>

<pre>
<?php 
global $wp_meta_boxes;
var_dump( $wp_meta_boxes );
?>
</pre>

</div><!--  // / inside -->
</div><!-- 	// / postbox -->