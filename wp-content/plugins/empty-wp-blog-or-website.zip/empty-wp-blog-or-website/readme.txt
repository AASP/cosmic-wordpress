=== Empty WP Blog/Website ===
Contributors: anoopmmc
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=anoopmmc%40gmail%2ecom&lc=US&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: delete posts, empty wp, delete users, empty pages, empty tags
Requires at least: 2.0.2
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

One click solution for make your blog/website empty. Delete all your posts, pages, media(images,videos,etc) , tags and categories.

== Description ==

One click solution for make your blog/website empty. Delete all your posts, pages, media(images,videos,etc) , tags and categories.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `empty-wp-blog.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WP
3. Go to Settings=> Empty WP Menu and Cofirm your action.

== Changelog ==

Added delete user feature