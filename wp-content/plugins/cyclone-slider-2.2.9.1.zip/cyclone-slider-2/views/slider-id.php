<?php if(!defined('ABSPATH')) die('Direct access denied.'); ?>

<div class="cycloneslider-field last">
	<input id="cycloneslider_post_name" type="text" name="post_name" value="<?php echo esc_attr($post_name); ?>" />
	<span class="note"><?php _e('Change the Slideshow ID here.', 'cycloneslider'); ?></span>
	<div class="clear"></div>
</div>
