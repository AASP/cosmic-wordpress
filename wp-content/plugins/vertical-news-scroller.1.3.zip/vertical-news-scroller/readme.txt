=== Vertical News Scroller ===
Contributors:nik00726
Tags:Vertical news,Vertical scrolling news,Scrolling news WordPress,WordPress dynamic news,Free scrolling news wordpress plugin,News plugin WordPress,WordPress set post or page as news
Donate link: http://www.i13websolution.com/donate_for_news_scroller.php
Requires at least:3.0
Tested up to:4.0
Stable tag:1.3
Version:1.3
License:GPLv2 or later
License URI:http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

**Now Support Upto WordPress 4.0**

Vertical News Scroller is plugin for display a vertical scrolling news for WordPress blog.Admin can manage any number of news.Admin can add,edit delete news.
 
Simple and easy news scroller.Admin can have option for display text with news or just news title only.Admin can add custom link to news.Pro version can have category wise news.



*   [Live Demo](http://www.i13websolution.com/wpdemo/wordpress-news-slider/)    


**Find Vertical News Scroller Pro Plugin (Unlimited News Categories + Much more fatures) at [I Thirteen Web Solution](http://www.i13websolution.com/wordpress-pro-plugins/wordpress-vertical-news-scroller-pro.html)**




=Features=

1. Add any number of news  
2. Display desired number of news to users.
3. Admin can manage scrolling news spped.
4. Admin can manage scrolling news height width.
5. Customized news as per your Wordpress Theme
6. No Need Of Knowledge of PHP, HTML .
7. Easy To Install Plugin
8. Premium Support Available
9. Admin can change font and other settings from css.
10. Responsive admin layout

=Pro Version Features=

1. Now support multiple news category(category wise news)
2. Now pro version has two type news style modern(jquery scroller) and classic(marquee).
3. Pro version support shortcode so you can print it any where in WordPress.
4. Admin can set any post or page as a news no need to add edit news manually.
5. Go to add or edit post or page and checkbox check add this post or page as news.
6. Go to add or edit post or page and checkbox check add this post or page as news.
7. Vertical News Scroller Open news link in same window Or In new tab
8. Responsive admin layout

[Get Support](http://www.i13websolution.com/contacts) 


== Installation ==


This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. Admin can set any post or page as a news no need to add edit news manually.
2. Go to add or edit post or page and checkbox check add this post or page as news.

1. upload vertical-news-scroller folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use Vertical News Scroller.

### Usage ###

1.Use of Vertical News Scroller is easy after activating plugin go to Manage Scrolling News menu.

2.Add some news atleast two,three news for good,But It can be any number of news.

3.Go to Appearance-->Widgets and drag and drop "Vertical news scroll" widget to your desired location(like left,right,footer).

4.Thats it your scrolling news will appear.

5.For css changes please change it to wp-content/plugins/vertical-news-scroller/CSS/newsscrollcss.css


== Screenshots ==

1. User site preview of scrolling news
2. Widget preview admin site. 
3. Admin manage news preview.
4. Vertical News Scroller Pro version add news directly from post/page add edit.
5. Vertical News Scroller Pro version News Scroller Type.
6. Vertical News Scroller Open news link in same window Or In new tab.
7. Pro version news categories.
8. Pro version add news.


== License ==

This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.

== Changelog ==

= 1.3 =

* Added support for single quote and double quote in news title .

= 1.2 =

* Bug fix for adding news with single quote and double quote 
  in news content and title.

* Css changes for admin panel.

* Release Pro version.

= 1.1 =

* Css not loading issue fixed.

* Add News Form validation not working fixed.


= 1.0 =

* Stable 1.0 first release


== Upgrade Notice ==

= 1.3 =

* Added support for single quote and double quote in news title .

* Bug fix for adding news with single quote and double quote 
  in news content and title.

* Css changes for admin panel.

* Release Pro version.

= 1.1 =

* Css not loading issue fixed.

* Add News Form validation not working fixed.

= 1.0 =

* Stable 1.0 first release

 
== Frequently Asked Questions ==

1.How to use ?

For frontend side use please use widget feature.more more info use readme installation and usage notes.