=== Sliding Contact Form By FormGet ===
Contributors: PankajAgarwal
Tags: contact form, contact, form, forms, form maker, contact form plugin, contact form builder, contact form with recaptcha, feedback form, contact us, request form, contact button, drag and drop contact form, file upload contact form, contact form to email, contact form payments, contact for paypal, form solution, form builder, feedback, easy contact form, helpdesk
Requires at least: 3.5.0
Tested up to: 3.5.1
Stable tag: 2.4

If you have a need to build and bespoke good looking form for your website, then you approached to exact spot!

== Description ==

Sliding Contact Form By FormGet is a advance contact form builder tool. This plugin helps you to capture users information from your site. You can build unlimited contact forms in a seconds using 
Contact Form Builder Option. With a simple drag and drop function, you can build a simple contact form, complex contact forms with the ability to collect payments. When you create a beautiful contact form with FormGet, it will automatically build database in the backend and generate scripts that will create contact form on any of your website or pages. FormGet host everything all you need to collect user data on your website. 

= This video will guide you on how you can create a sliding form with FormGet for your WordPress site. =

http://vimeo.com/84850928


= This advance user friendly contact form creator includes some amazing features such as: =

*  You can add unlimited number of contact form fields including different type of text input form fields, captcha, textarea and form submission button.
*  Sliding Contact Form By FormGet plugin allow to create contact form visually along with real time visual contact form editor.
*  You can also add validation rule to your contact form.
*  Language customization for all text and labels in the contact form.
*  Sliding Contact Form By FormGet allow you to set all the parameter such as font, color, custom branding, look and feel-layout and more.
*  Manage multiple contact forms within a single dashboard.  
*  Allow unlimited tickets creation in your contact form.
*  User can collect payments in the contact form itself using PayPal payment system.
*  Assign agents based on the ticket category of your contact form.
*  Agent alert with an email on every ticket received via contact form.
*  Send confirmation email on receive of contact form entry.
*  Sliding Contact Form By FormGet support shortcode, so that contact form can visible on any page and post.
*  Implemented Logic Forms to integrate logical conditions in your contact form that will show or hide form fields or questions according to the user's response to previous field.
*  Upload your Custom Background and header image.
* Color customization can be done by using advance color customizer.
* Share your contact forms on Facebook, Twitter, Google Plus go generate leads.

The backend interface of the Sliding Contact Form By FormGet plugin is intuitive and user friendly which allow users far from scripting and programming to create contact form. Our Sliding Contact Form By FormGet
plugs in at any of the given direction(left, right or bottom) you choose, of every page on your website and display a Contact Us button to generate more leads. You can also select the background color for your contact form that will complement your contact form.
You can also display your Contact Form individually on pages, post, widgets and sidebar, by using the WordPress shortcode and sidebar widget. 

Sliding Contact Form By FormGet flawlessly redeem FormGet to your WordPress Website. No more swapping between website to edit contact forms, view submission and copy code. Sliding Contact Form By FormGet let you manage your FormGet account from your wordpress dashboard, so can take advantage of all FormGet great feature without leaving your editor. 

Sliding Contact Form By FormGet is powered by formget.com.
Click here to build [Advance Contact Form](http://formget.com).

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `Sliding Contact Form By FormGet` folder to the `/wp-content/plugins/` directory.
2. Activate the contact form plugin through the 'Plugins' menu in WordPress.
3. Contact form tab will appear on the bottom left of the WordPress dashboard. 
4. Just click on the contact form tab and your online contact form builder will appear. 
5. Now just create your contact form and save it. 
6. Click on the embed button and copy the iframe code from "Embed Form On Your Website" tab.
7. Paste it in the plugin section.

== Screenshots ==

1. Contact Us tab plugs in left direction.
2. Sliding contact form from left side.
3. Contact Us tab plugs in right direction.
4. Sliding contact form from right direction.
5. Contact Us tab plugs in bottom.
6. Sliding contact form from bottom.

== Frequently Asked Questions ==

= Will Sliding Contact Form By FormGet Plugin work with my latest WordPress installation ? =

Yes, Sure Sliding Contact Form By FormGet plugin is tested and created with new version of WordPress.

= Will Sliding Contact Form By FormGet Plugin work with my themes? =

Of course! Sliding Contact Form By FormGet Plugin works out-of-the-box with every WordPress themes and other plugins. It work with the vast majority of premium and free themes, without requiring any coding.

= Where can I report a bug? =

Report bugs and participate in development at http://www.formget.com/contact-us/.

= How can I add contact form to my website? =
In order to add contact form to your website go to the Help section of plugin.

= Does the Sliding Contact Form By FormGet Plugin save the request in database so that admin can view it? =

Because we host everything, when you design a contact form with FormGet it automatically builds database. You can view all your entries from your dashboard of FormGet by making yourself logged in.

= How can customer log their Queries? =

When you create account in FormGet you automatically get support desk. All the entries submitted from FormGet form that you have embeded on your website, get automatically converted into ticket that you can get working on, from your account. Sliding Contact Form By FormGet Plugin let you collect feedback and queries directly from your website.


== Changelog ==

= Version 2.4 =
* Dashboard CSS improved. 

= Version 2.3 =
* Contact form CSS improved.
* integrated with email marketing system.
* Widget CSS improve.

= Version 2.2 =
* Added FormGet widget, now u can add FormGet contact form at sidebar and footer also.
* Can remove embed code.

= Version 2.1 =
* Improvement in CSS.

= Version 2.0 =
* Improvement in FormGet User Interface. Faster and smooth user experience.

= Version 1.9 =
* Activation error resolved.
* New banner image with our mascot.

= Version 1.8 =
* CSS bug fixed.

= Version 1.7 =
* sliding issues resolve.

= Version 1.6 =
* CSS bug fixed.

= Version 1.5 =
* New video added.

= Version 1.4 =
* CSS bug fixed.
* video added in plugin.
* Form Examples added.

= Version 1.3 =
* Button text and color can be customized .


= Version 1.2 =
* CSS bud fixed.
* Implemented Logic in Contact Form.

= Version 1.1 =
* CSS bud fixed.

= Version 1.0 =
* Initial release

== Upgrade Notice ==
= 1.0 =
* Initial release

= 1.1 =
* There is a new version of Sliding Contact Form By FormGet available.

= 1.4 =
* There is a new version of Sliding Contact Form By FormGet available.

= 1.5 =
* There is a new version of Sliding Contact Form By FormGet available.