<?php

/*
Silence in haiku
This hides the directory
Silence is golden
*/
