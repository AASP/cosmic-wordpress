<?php
// Customised, templated silence is one of the most golden varieties.
?>