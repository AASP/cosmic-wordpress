<?php
// Customised silence is even more golden.
